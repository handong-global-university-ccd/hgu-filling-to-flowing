"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import ArrowUpRight from "@/components/icons/ArrowUpRight";
import { asset } from "@/lib/asset";

export type OtherItem = { slug: string; title: string; thumbnail: string };

/** Figma Works 상세 Others (1807:14543~) — 352×222, 간격 0, 화면 전체 폭으로 흐른다 */
const TILE_W = 352;
const TILE_H = 222;
/** 썸네일 한 세트가 한 바퀴 도는 시간(초) — 기존 CSS 마퀴와 같은 속도 */
const LOOP_SECONDS = 60;
/** 이만큼 넘게 끌면 드래그로 보고 링크 클릭을 막는다 */
const DRAG_THRESHOLD = 5;

/**
 * 인터렉션 설명 (1837:11696)
 * - 좌측 첫 번째가 현재 작품의 다음 순서이고 그 뒤로 이어진다 (getOtherWorks)
 * - 호버 전에는 계속 흐르고, 호버하면 멈춘다
 * - 호버 중에는 좌우로 끌어서(트랙패드 가로 스크롤 포함) 직접 넘길 수 있다
 * - 영역을 벗어나면 멈췄던(끌어 놓은) 위치에서 다시 흐른다
 * - 양쪽 어느 방향으로 끌어도 끊김 없이 무한 반복
 * - 호버한 썸네일에는 흰색 80% 레이어 + 제목 + 화살표가 올라온다
 *
 * CSS 애니메이션으로는 '드래그한 위치에서 이어 흐르기'가 안 돼서
 * 위치(offset)를 직접 들고 rAF 로 움직인다. 리렌더 없이 transform 만 바꾼다.
 */
export default function OthersMarquee({ items }: { items: OtherItem[] }) {
  const viewport = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const setWidth = items.length * TILE_W;
  // 화면을 다 채우고도 한 세트가 남도록 복제 개수를 정한다 (작품 수가 적어도 빈칸 없이)
  const [copies, setCopies] = useState(2);
  // 드래그 직후 발생하는 click 을 막기 위한 플래그 (렌더와 무관해서 ref)
  const suppressClick = useRef(false);

  useEffect(() => {
    const element = viewport.current;
    if (!element || setWidth === 0) return;
    const update = () => setCopies(Math.max(2, Math.ceil(element.clientWidth / setWidth) + 1));
    update();
    const observer = new ResizeObserver(update);
    observer.observe(element);
    return () => observer.disconnect();
  }, [setWidth]);

  useEffect(() => {
    const element = viewport.current;
    const strip = track.current;
    if (!element || !strip || setWidth === 0) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const speed = setWidth / (LOOP_SECONDS * 1000); // px/ms
    let offset = 0; // (-setWidth, 0] 범위로 유지
    let hovered = false;
    let pointerId: number | null = null;
    let startX = 0;
    let startOffset = 0;
    let lastX = 0;
    let lastTime = 0;
    let velocity = 0; // 놓은 뒤 관성 (px/ms)
    let previous = performance.now();
    let raf = 0;

    const wrap = (value: number) => ((value % setWidth) - setWidth) % setWidth || 0;
    const render = () => {
      strip.style.transform = `translate3d(${offset}px, 0, 0)`;
    };

    const tick = (now: number) => {
      const dt = Math.min(now - previous, 64); // 탭 전환 후 한 번에 튀지 않게
      previous = now;
      if (pointerId === null) {
        if (Math.abs(velocity) > 0.01) {
          offset += velocity * dt;
          velocity *= Math.pow(0.95, dt / 16);
        } else {
          velocity = 0;
          if (!hovered && !reduceMotion) offset -= speed * dt;
        }
        offset = wrap(offset);
        render();
      }
      raf = requestAnimationFrame(tick);
    };

    const onEnter = (event: PointerEvent) => {
      if (event.pointerType === "mouse") hovered = true;
    };
    const onLeave = (event: PointerEvent) => {
      if (event.pointerType === "mouse" && pointerId === null) hovered = false;
    };
    const onDown = (event: PointerEvent) => {
      if (event.button !== 0) return;
      pointerId = event.pointerId;
      startX = lastX = event.clientX;
      startOffset = offset;
      lastTime = performance.now();
      velocity = 0;
      suppressClick.current = false;
      // 터치는 손을 대는 동안 멈춰 있어야 하므로 호버처럼 다룬다
      if (event.pointerType !== "mouse") hovered = true;
    };
    const onMove = (event: PointerEvent) => {
      if (event.pointerId !== pointerId) return;
      const dx = event.clientX - startX;
      if (!suppressClick.current && Math.abs(dx) > DRAG_THRESHOLD) {
        suppressClick.current = true;
        element.setPointerCapture(event.pointerId);
      }
      if (!suppressClick.current) return;
      const now = performance.now();
      if (now > lastTime) velocity = (event.clientX - lastX) / (now - lastTime);
      lastX = event.clientX;
      lastTime = now;
      offset = wrap(startOffset + dx);
      render();
    };
    const onUp = (event: PointerEvent) => {
      if (event.pointerId !== pointerId) return;
      pointerId = null;
      // 손을 멈춘 뒤 놓았으면 관성 없이 그 자리에
      if (performance.now() - lastTime > 80) velocity = 0;
      velocity = Math.max(-3, Math.min(3, velocity));
      if (event.pointerType !== "mouse") hovered = false;
      else hovered = element.matches(":hover");
    };
    // 트랙패드 가로 스와이프로도 넘길 수 있게 — 세로 스크롤은 페이지에 그대로 넘긴다
    const onWheel = (event: WheelEvent) => {
      if (Math.abs(event.deltaX) <= Math.abs(event.deltaY)) return;
      event.preventDefault();
      velocity = 0;
      offset = wrap(offset - event.deltaX);
      render();
    };

    element.addEventListener("pointerenter", onEnter);
    element.addEventListener("pointerleave", onLeave);
    element.addEventListener("pointerdown", onDown);
    element.addEventListener("pointermove", onMove);
    element.addEventListener("pointerup", onUp);
    element.addEventListener("pointercancel", onUp);
    element.addEventListener("wheel", onWheel, { passive: false });
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      element.removeEventListener("pointerenter", onEnter);
      element.removeEventListener("pointerleave", onLeave);
      element.removeEventListener("pointerdown", onDown);
      element.removeEventListener("pointermove", onMove);
      element.removeEventListener("pointerup", onUp);
      element.removeEventListener("pointercancel", onUp);
      element.removeEventListener("wheel", onWheel);
    };
  }, [setWidth]);

  if (items.length === 0) return null;

  return (
    <div
      ref={viewport}
      className="touch-pan-y overflow-hidden select-none"
      onClickCapture={(event) => {
        if (suppressClick.current) {
          event.preventDefault();
          event.stopPropagation();
          suppressClick.current = false;
        }
      }}
      onDragStart={(event) => event.preventDefault()}
    >
      <div ref={track} className="flex w-max will-change-transform">
        {Array.from({ length: copies }, (_, copy) => (
          <div key={copy} className="flex shrink-0" aria-hidden={copy > 0 || undefined}>
            {items.map((w) => (
              <Link
                key={w.slug}
                href={`/works/${w.slug}/`}
                tabIndex={copy > 0 ? -1 : undefined}
                draggable={false}
                className="group/tile relative block shrink-0"
                style={{ width: TILE_W, height: TILE_H }}
              >
                <Image
                  src={asset(w.thumbnail)}
                  alt={copy > 0 ? "" : w.title}
                  width={TILE_W}
                  height={TILE_H}
                  draggable={false}
                  className="pointer-events-none size-full object-cover"
                />
                <span className="absolute inset-0 bg-bg/80 opacity-0 transition-opacity duration-200 group-hover/tile:opacity-100" />
                <span className="absolute inset-0 grid place-items-center px-6 text-center font-kr text-body text-fg-secondary opacity-0 transition-opacity duration-200 group-hover/tile:opacity-100">
                  {w.title}
                </span>
                <ArrowUpRight
                  aria-hidden
                  className="absolute right-1.5 bottom-1.5 size-6 text-fg-secondary opacity-0 transition-opacity duration-200 group-hover/tile:opacity-100"
                />
              </Link>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
