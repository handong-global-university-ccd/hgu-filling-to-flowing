"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import WorkCard from "./WorkCard";
import EmptyResult from "@/components/common/EmptyResult";
import { useWorksFilter } from "./works-filter";
import { isFieldKey, type Work } from "@/data/types";
import { getProjects, inProject } from "@/data/projects";
import { cn } from "@/lib/cn";

type Item = { work: Work; designerNames: string };

/**
 * Works 본문 — Figma Works (2564:9040 AX/팀 · 2564:9184 AX/개인 · 2564:8888·8203 커뮤니케이션 ·
 * 2564:9368 서비스 · 2564:8431·8583 UX · 2561:5623 공간 · 2573:25419·25523 스크롤)
 *
 * - 분야 탭·검색은 헤더 둘째 줄에 있다 (Header.tsx)
 * - 왼쪽 3칸 : 분야 안의 전시 목록. 고른 항목만 검정 + 6px 사각 점, 나머지 Neutral/300.
 *              스크롤해도 제자리에 남는다 — 헤더가 Scroll(74px) 로 접히면 그 아래 48px(top 122)에 붙는다
 * - 왼쪽 칸 항목 사이 4 (2670:5150)
 * - 오른쪽 9칸 : 전시 제목(Body/Large) · 지도교수 · 소개글(16/1.7, 문단 사이 4) → 52 아래 작품 3열 (가로 16, 세로 64)
 * - All 은 소개글 없이 전체 작품. 왼쪽 칸은 비워 둔다 (분야 탭이 헤더에 있다)
 * - 작품 순서는 페이지에 들어올 때마다 랜덤 — 서버 HTML 은 데이터 순서라 섞기 전에는 그리드를 숨긴다
 */
export default function WorksBrowser({ items }: { items: Item[] }) {
  const filter = useWorksFilter();
  const reduce = useReducedMotion();
  // Works 에는 분야 탭만 있다 — 전공(Designers 탭) 값이 주소로 넘어오면 All 로 본다
  const rawField = filter?.field ?? "all";
  const field = isFieldKey(rawField) ? rawField : "all";
  const q = filter?.q ?? "";

  const projects = useMemo(() => (field === "all" ? [] : getProjects(field)), [field]);
  const project = projects.find((p) => p.key === filter?.project) ?? projects[0];

  // 들어올 때마다 작품 순서를 섞는다 (Fisher–Yates). 서버·첫 렌더와 어긋나지 않게 마운트 뒤에 정한다
  const [rank, setRank] = useState<Map<string, number> | null>(null);
  useEffect(() => {
    const slugs = items.map((i) => i.work.slug);
    for (let i = slugs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [slugs[i], slugs[j]] = [slugs[j], slugs[i]];
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRank(new Map(slugs.map((s, i) => [s, i])));
  }, [items]);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = rank
      ? [...items].sort((a, b) => (rank.get(a.work.slug) ?? 0) - (rank.get(b.work.slug) ?? 0))
      : items;
    return list.filter(({ work, designerNames }) => {
      if (project && !inProject(work, project)) return false;
      if (!query) return true;
      return (
        (work.cardTitle ?? work.title).toLowerCase().includes(query) ||
        designerNames.toLowerCase().includes(query)
      );
    });
  }, [items, project, q, rank]);

  // 다른 분야·전시로 바꾸면 소개글부터 다시 보이게 맨 위로
  const scope = project?.key ?? field;
  const firstScope = useRef(scope);
  useEffect(() => {
    if (scope === firstScope.current) return;
    firstScope.current = scope;
    if (window.scrollY > 0) window.scrollTo({ top: 0 });
  }, [scope]);

  const nav = projects.map((p) => ({
    key: p.key,
    label: p.label,
    active: p.key === project?.key,
    select: () => filter?.setProject(p.key),
  }));

  return (
    <div className="pb-75 max-lg:px-margin max-lg:pb-[86px] lg:page-grid lg:pt-[49px]">
      {/* 왼쪽 칸 — 모바일(2573:9729)은 헤더 아래 6 에 세로 목록 12/18, 사이 4. All 에서는 빈 칸 */}
      {field === "all" ? (
        <div aria-hidden className="max-lg:hidden lg:col-span-3" />
      ) : (
        <nav
          aria-label="전시"
          className="self-start max-lg:pt-1.5 lg:sticky lg:top-[122px] lg:col-span-3 lg:pl-1"
        >
          <ul className="flex flex-col gap-1 text-body max-lg:font-kr max-lg:text-[12px] max-lg:leading-[18px]">
            {nav.map((n) => (
              <li key={n.key}>
                <button
                  type="button"
                  onClick={n.select}
                  aria-current={n.active ? "true" : undefined}
                  className={cn(
                    "flex items-center gap-[11px] text-left transition-colors max-lg:gap-2",
                    n.active ? "text-fg" : "text-neutral-300 hover:text-fg-secondary",
                  )}
                >
                  {n.active && <span aria-hidden className="size-1.5 shrink-0 bg-current" />}
                  {n.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <motion.div
        key={scope}
        initial={reduce ? false : { opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={cn("lg:col-span-9", project ? "max-lg:mt-7" : "max-lg:mt-[11px]")}
      >
        {project && (
          <header className="mb-[52px] font-kr text-fg-secondary max-lg:mb-2">
            {project.title && (
              <h1 className="text-body-lg max-lg:text-[14px] max-lg:leading-[22px]">{project.title}</h1>
            )}
            <p className="mt-1 text-kr-body leading-[1.7] max-lg:hidden">지도교수 | {project.advisor}</p>
            {/* 모바일은 "지도교수: 이름" 10/16 */}
            <p className="mt-1 text-[10px] leading-4 lg:hidden">지도교수: {project.advisor}</p>
            {project.intro.length > 0 && (
              <>
                <div className="mt-6 flex max-w-[1067px] flex-col gap-1 text-kr-body leading-[1.7] break-keep max-lg:hidden lg:whitespace-pre-line">
                  {project.intro.map((para) => (
                    <p key={para.slice(0, 24)}>{para}</p>
                  ))}
                </div>
                <MobileIntro key={project.key} paragraphs={project.intro} />
              </>
            )}
          </header>
        )}

        <ul
          className={cn(
            "grid grid-cols-2 gap-x-gutter gap-y-8 max-lg:gap-3 md:gap-y-16 lg:grid-cols-3",
            !rank && "invisible",
          )}
        >
          {filtered.map(({ work, designerNames }) => (
            <li key={work.slug}>
              <WorkCard work={work} designerName={designerNames} />
            </li>
          ))}
        </ul>
        {rank && filtered.length === 0 && (
          <EmptyResult>{q.trim() ? "검색 결과가 없습니다." : "작품을 준비하고 있습니다."}</EmptyResult>
        )}
      </motion.div>
    </div>
  );
}

/**
 * 모바일 전시 소개 (2573:9729 접힘 / 2573:9849 펼침) — 12/1.5, 위 16.
 * 접힌 상태는 5줄까지, 오른쪽 아래 "더보기"(10px 밑줄). 누르면 전체 + 문단 사이 한 줄 띄움, "닫기"
 */
function MobileIntro({ paragraphs }: { paragraphs: string[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-4 text-[12px] leading-[1.5] lg:hidden">
      <div className={open ? "flex flex-col gap-[18px]" : "line-clamp-5"}>
        {paragraphs.map((para) => (
          <p key={para.slice(0, 24)} className={cn(!open && "inline")}>
            {para.replace(/\n/g, " ")}{" "}
          </p>
        ))}
      </div>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="mt-0.5 ml-auto block text-[10px] leading-[1.5] tracking-[0.02em] text-fg-tertiary underline"
      >
        {open ? "닫기" : "더보기"}
      </button>
    </div>
  );
}
