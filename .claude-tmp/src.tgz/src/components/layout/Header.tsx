"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "motion/react";
import { NAV } from "@/lib/site";
import { cn } from "@/lib/cn";
import { FIELDS, MAJORS } from "@/data/types";
import { useWorksFilter } from "@/components/works/works-filter";
import { useHasFinePointer, useMediaQuery } from "@/hooks/useMediaQuery";
import { HEADER_H, MOBILE_QUERY } from "@/lib/header";
import Logo from "./Logo";
import ArrowUpRight from "@/components/icons/ArrowUpRight";
import SearchIcon from "@/components/icons/Search";

export type ArchiveTab = "behind" | "exhibition";

/** 숨은 헤더를 다시 불러내는 화면 상단 영역(px) */
const REVEAL_ZONE = 120;

/** 헤더 내비 순서는 Figma 헤더(1696:14396) 기준 — 푸터·모바일 메뉴(NAV)와 순서가 다르다 */
const HEADER_NAV = (["/works", "/designers", "/about", "/archive"] as const).map((href) =>
  NAV.find((item) => item.href === href)!,
);

const ARCHIVE_TABS = [
  { key: "behind", label: "Behind", href: "/archive/" },
  { key: "exhibition", label: "Exhibition View", href: "/archive/exhibition/" },
] as const;

/**
 * Figma Search (2357:18591) — 298×30, 아래 0.5px Neutral/500 밑줄, placeholder Neutral/500
 * 검색어가 있으면 오른쪽 끝에 X(지우기)를 항상 띄운다 — 브라우저 기본 X 는 호버·포커스 때만 보여서 숨긴다 (댓글 #202)
 */
function SearchField({
  value,
  onChange,
  className,
}: {
  value?: string;
  onChange?: (v: string) => void;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative flex h-[30px] w-full shrink-0 items-start border-b-[0.5px] border-border-strong md:w-[298px]",
        className,
      )}
    >
      <label className="flex-1">
        <span className="sr-only">검색</span>
        <input
          type="search"
          {...(onChange ? { value, onChange: (e) => onChange(e.target.value) } : {})}
          placeholder="Search"
          className="w-full bg-transparent pr-6 text-body outline-none placeholder:text-fg-tertiary [&::-webkit-search-cancel-button]:appearance-none"
        />
      </label>
      {onChange && value && (
        <button
          type="button"
          onClick={() => onChange("")}
          aria-label="검색어 지우기"
          className="absolute top-[5px] right-0 grid size-4 place-items-center text-fg-tertiary transition-colors hover:text-fg"
        >
          <svg
            viewBox="0 0 16 16"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.25"
            strokeLinecap="round"
            aria-hidden
            className="size-4"
          >
            <path d="M4 4l8 8M12 4l-8 8" />
          </svg>
        </button>
      )}
    </div>
  );
}

/**
 * 모바일 전체 화면 메뉴 (< 768px). 데스크톱 내비 4개를 화면 가득 크게 보여준다.
 * 헤더는 transform·overflow 가 걸려 있어 그 안에 두면 잘리므로 body 로 포털한다.
 */
function MobileMenu({
  open,
  onClose,
  inverse,
  pathname,
}: {
  open: boolean;
  onClose: () => void;
  inverse: boolean;
  pathname: string;
}) {
  useEffect(() => {
    if (!open) return;
    const root = document.documentElement;
    const previous = root.style.overflow;
    root.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      root.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (typeof document === "undefined") return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label="메뉴"
          data-lenis-prevent
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className={cn(
            "fixed inset-0 z-[70] flex flex-col px-margin pt-4 pb-8 md:hidden",
            inverse ? "bg-bg-inverse text-fg-inverse" : "bg-bg text-fg",
          )}
        >
          <div className="flex items-start justify-between">
            <Link href="/" aria-label="홈으로" onClick={onClose}>
              <Logo width={109} />
            </Link>
            <button type="button" onClick={onClose} className="text-body-sm" autoFocus>
              Close
            </button>
          </div>
          <nav aria-label="주요 메뉴" className="mt-auto">
            {/* Figma 목차 (2573:20747) — Medium 20/27, 간격 12, 왼쪽 25. 지금 페이지만 글자색 그대로·나머지 Neutral/500 */}
            <ul className="flex flex-col gap-3 pl-[9px] text-[20px] leading-[27px] font-medium">
              <li>
                <Link href="/" onClick={onClose} className={pathname === "/" ? "" : "text-fg-tertiary"}>
                  Home
                </Link>
              </li>
              {NAV.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={onClose}
                    aria-current={pathname.startsWith(item.href) ? "page" : undefined}
                    className={pathname.startsWith(item.href) ? "" : "text-fg-tertiary"}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

/**
 * Figma 헤더 컴포넌트 (1696:14396 — Default 1752:13601 / Scroll 2357:17939 / White 1721:12663 · Black 1721:12723)
 *
 * - 둘째 줄 없음 : 110px 고정. 로고 + 우측 내비.  inverse 면 Black 변형
 * - 둘째 줄 있음 : Default 176px ↔ Scroll 74px. (padding 24, 두 줄 사이 44)
 *                  아래로 스크롤하면 로고·내비 행이 접히고 둘째 줄만 남는다.
 *                  최상단이거나 헤더에 호버하면 다시 펼쳐진다.
 *   · filters : Works 의 분야 탭 + 검색 (1807:14578)
 *   · archive : Behind / Exhibition View 탭 + 검색 (1807:15967, 1807:16563)
 *   · compact : 처음부터 접힌 상태 (디자이너 상세 1807:15093)
 *   hideOnScroll 이어도 둘째 줄은 숨지 않는다 — 숨는 대신 Scroll(74px) 로 접힌다
 */
export default function Header({
  inverse = false,
  filters = false,
  archive,
  compact = false,
  hideOnScroll = false,
  overlay = false,
  height = 110,
  mobileTitle,
}: {
  inverse?: boolean;
  filters?: boolean;
  archive?: ArchiveTab;
  /** 스크롤과 상관없이 Scroll(74px) 상태로 시작한다 — 호버하면 펼쳐진다 */
  compact?: boolean;
  /**
   * 아래로 스크롤하면 헤더를 숨기고, 마우스가 화면 위쪽으로 가면 다시 내려온다.
   * 스크롤이 없는 화면에서는 커서가 위쪽을 벗어나기만 해도 숨는다.
   */
  hideOnScroll?: boolean;
  /**
   * 본문 위에 떠 있는 헤더 (홈 2564:5091 — 시안에 헤더가 없고 키비주얼이 맨 위에서 시작한다).
   * 마우스 기기에서는 최상단에서도 숨어 있다가 커서를 화면 위쪽으로 올리면 내려온다. hideOnScroll 과 같이 쓴다
   */
  overlay?: boolean;
  /** 둘째 줄이 없는 단순 헤더의 전체 높이(px). 위 여백 24px 을 포함한 값이다 */
  height?: number;
  /**
   * 모바일 전용: 로고 대신 ← 뒤로가기 + 가운데 제목 (디자이너 상세 2491:3761).
   * 이때 모바일은 compact 여도 처음에 펼쳐진 상태로 시작한다.
   */
  mobileTitle?: { title: string; backHref: string };
}) {
  const pathname = usePathname();
  const { scrollY } = useScroll();
  const [atTop, setAtTop] = useState(true);
  const [hovered, setHovered] = useState(false);
  // 처음에는 보인 상태로 둔다 — 커서를 한 번이라도 아래로 내려야 숨는다
  const [nearTop, setNearTop] = useState(!overlay);
  const [scrollable, setScrollable] = useState(true);
  const filter = useWorksFilter();
  const isMobile = useMediaQuery(MOBILE_QUERY);
  const finePointer = useHasFinePointer();
  const [menuOpen, setMenuOpen] = useState(false);
  // 모바일 필터 헤더: 검색창은 돋보기를 눌러야 첫 줄 자리에 열린다
  const [searchOpen, setSearchOpen] = useState(false);
  // 터치 기기는 커서로 헤더를 불러낼 수 없으니 위로 스크롤하면 다시 보여준다
  const [scrollingDown, setScrollingDown] = useState(false);

  // 홈은 인트로 아래에서 본문이 시작한다 — 모바일 홈 헤더가 투명한 구간(본문 맨 위)을 인트로 높이만큼 내려 잡는다
  const [atPageTop, setAtPageTop] = useState(true);
  // 홈: 인트로를 지나 본문(레이어)이 화면 맨 위에 닿으면 헤더를 상단에 고정한다 — 인트로 동안만 숨는다
  const [pastIntro, setPastIntro] = useState(false);
  useMotionValueEvent(scrollY, "change", (y) => {
    setAtTop(y < 40);
    const intro = overlay ? (document.querySelector<HTMLElement>("[data-intro]")?.offsetHeight ?? 0) : 0;
    setAtPageTop(y < intro + 40);
    setPastIntro(overlay && y >= intro - 1);
    const previous = scrollY.getPrevious() ?? 0;
    if (Math.abs(y - previous) > 4) setScrollingDown(y > previous);
  });

  // 이번 세션에 인트로를 이미 지났으면 홈이 인트로 아래에서 바로 시작한다 — 스크롤 이벤트 없이도 맞춘다
  useEffect(() => {
    if (!overlay) return;
    const check = () => {
      const intro = document.querySelector<HTMLElement>("[data-intro]")?.offsetHeight ?? 0;
      setPastIntro(window.scrollY >= intro - 1);
    };
    check();
    const id = setTimeout(check, 300);
    return () => clearTimeout(id);
  }, [overlay]);

  // 페이지를 옮기면 메뉴를 닫는다
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  // 숨어 있는 동안에는 헤더가 포인터 이벤트를 못 받으니 화면 전체에서 커서 높이를 본다
  useEffect(() => {
    if (!hideOnScroll) return;
    const onMove = (e: PointerEvent) => setNearTop(e.clientY <= REVEAL_ZONE);
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [hideOnScroll]);

  // 아카이브 비하인드처럼 스크롤이 아예 없는 화면에서는 커서 위치만으로 판단한다
  useEffect(() => {
    if (!hideOnScroll) return;
    const check = () => setScrollable(document.documentElement.scrollHeight > window.innerHeight + 4);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, [hideOnScroll]);

  const hidden =
    overlay && pastIntro
      ? false
      : finePointer
        ? hideOnScroll && !nearTop && !hovered && (overlay || !scrollable || !atTop)
        : hideOnScroll && scrollable && !atTop && !atPageTop && scrollingDown && !menuOpen;
  // 둘째 줄이 있는 헤더는 통째로 숨지 않고 Scroll(74px) 로 접혀 둘째 줄(탭)만 남긴다
  const expanded =
    compact && !(isMobile && mobileTitle) ? hovered : (atTop || hovered || searchOpen) && !hidden;
  const showFilterRow = filters && filter !== null;

  const brand = inverse ? "bg-bg-inverse text-fg-inverse" : "bg-bg text-fg";

  /* 로고(190×58.5) + 주요 내비 — Figma: 항목 간격 57px, 오른쪽 끝은 마진 안쪽 8px(행 폭 1864), Body/Medium(16/26) */
  const searchButton = showFilterRow && filter && (
    <button
      type="button"
      onClick={() => setSearchOpen(true)}
      aria-label="검색"
      aria-expanded={searchOpen}
      className="relative md:hidden"
    >
      <SearchIcon className="size-4" />
      {/* 검색어가 걸려 있으면 작은 점으로 알려준다 */}
      {filter.q.trim() && <span aria-hidden className="absolute top-0 right-0 size-1.5 bg-current" />}
    </button>
  );

  const topRow = (
    <div className="flex w-full items-start justify-between max-md:items-center">
      {mobileTitle ? (
        <>
          {/* 모바일 디자이너 상세 — ← (arrow-up-right 를 -135° 돌린 것) + 가운데 제목 */}
          <BackLink href={mobileTitle.backHref} />
          <Link href="/" aria-label="홈으로" className="max-md:hidden">
            <Logo width={190} />
          </Link>
        </>
      ) : (
        <Link href="/" aria-label="홈으로">
          <Logo width={190} className="max-md:!w-[109px]" />
        </Link>
      )}
      {/* 모바일 (2573:10142): 돋보기 16 · 간격 20 · Menu 12/22 */}
      <div className="flex items-center gap-5 md:hidden">
        {searchButton}
        {/* 모바일: 내비 대신 메뉴 버튼 → 전체 화면 메뉴 */}
        {!mobileTitle && (
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            className="text-[12px] leading-[22px]"
          >
            Menu
          </button>
        )}
      </div>
      <nav aria-label="주요 메뉴" className="pr-2 max-md:hidden">
        <ul className="flex items-center gap-[57px] text-right text-body">
          {HEADER_NAV.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={pathname.startsWith(item.href) ? "page" : undefined}
                className="transition-opacity hover:opacity-60"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );

  /* 모바일 검색 — 돋보기를 누르면 첫 줄(로고 자리)이 검색창으로 바뀐다. 시안에 열린 상태가 없어 데스크톱 검색창 모양을 따른다 */
  const firstRow =
    searchOpen && filter ? (
      <>
        <div className="flex h-[34px] w-full items-center gap-4 md:hidden">
          <label className="flex-1 border-b border-border">
            <span className="sr-only">검색</span>
            <input
              type="search"
              autoFocus
              value={filter.q}
              onChange={(e) => filter.setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === "Escape") setSearchOpen(false);
              }}
              placeholder="Search"
              className="w-full bg-transparent text-body outline-none placeholder:text-fg-tertiary"
            />
          </label>
          <button type="button" onClick={() => setSearchOpen(false)} className="text-body-sm">
            Close
          </button>
        </div>
        <div className="max-md:hidden">{topRow}</div>
      </>
    ) : (
      topRow
    );

  /* 둘째 줄 — 탭 간격 12px, 비활성 Neutral/300, Body/Medium(16/26) */
  let secondRow: React.ReactNode = null;

  if (showFilterRow && filter) {
    // Designers 는 전공 탭 (Figma 1807:14949 — All / Product Design / Visual Design), Works 는 분야 탭
    const tabs = [
      { key: "all" as const, label: "All" },
      ...(pathname.startsWith("/designers") ? MAJORS : FIELDS),
    ];
    const renderTab = (t: (typeof tabs)[number]) => (
      <button
        key={t.key}
        type="button"
        role="tab"
        aria-selected={filter.field === t.key}
        onClick={() => filter.setField(t.key)}
        className={cn(
          "w-fit whitespace-nowrap transition-colors",
          filter.field === t.key ? "text-fg" : "text-neutral-300 hover:text-fg-secondary",
        )}
      >
        {/* 모바일 탭은 "Design" 을 뺀 짧은 이름 (2573:10142) */}
        <span className="md:hidden">{t.label.replace(/ Design$/, "")}</span>
        <span className="max-md:hidden">{t.label}</span>
      </button>
    );
    secondRow = (
      <div className="mt-auto flex flex-col md:flex-row md:items-center md:justify-between md:gap-6 md:px-1">
        {/* 모바일 (2573:10142): All 과 분야를 한 줄에 12/26 — 넘치면 가로로 밀어서 본다 */}
        <div
          role="tablist"
          aria-label={pathname.startsWith("/designers") ? "전공" : "분야"}
          className="-mx-margin flex [scrollbar-width:none] gap-3 overflow-x-auto px-margin text-[12px] leading-[26px] md:mx-0 md:flex-wrap md:overflow-visible md:px-0 md:text-body [&::-webkit-scrollbar]:hidden"
        >
          {tabs.map(renderTab)}
        </div>
        {/* 모바일은 돋보기 버튼으로 연다 */}
        <SearchField value={filter.q} onChange={filter.setQ} className="max-md:hidden" />
      </div>
    );
  } else if (archive) {
    secondRow = (
      <div className="mt-auto flex items-center justify-between gap-6 md:px-1">
        {/* 모바일 (2573:20571): 12/18 Medium, 왼쪽 4 들여서 위에서 84 */}
        <nav
          aria-label="아카이브"
          className="flex gap-3 text-body max-md:-mb-0.5 max-md:pl-1 max-md:text-caption"
        >
          {ARCHIVE_TABS.map((t) => (
            <Link
              key={t.key}
              href={t.href}
              aria-current={archive === t.key ? "page" : undefined}
              className={cn(
                "whitespace-nowrap transition-colors",
                archive === t.key ? "" : "text-neutral-300 hover:text-fg-secondary",
              )}
            >
              {t.label}
            </Link>
          ))}
        </nav>
      </div>
    );
  }

  const menu = (
    <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} inverse={inverse} pathname={pathname} />
  );

  // 모바일 상세 (2563:7046 작품 · 2573:10650 디자이너): 로고·메뉴 없이 ← 하나만. 높이 46 (위 16 + 18 + 12)
  if (isMobile && mobileTitle) {
    return (
      <header className={cn("fixed inset-x-0 top-0 z-50 h-[46px] px-margin pt-4", brand)}>
        <BackLink href={mobileTitle.backHref} />
      </header>
    );
  }

  if (!secondRow) {
    return (
      <>
        <motion.header
          onPointerEnter={() => setHovered(true)}
          onPointerLeave={() => setHovered(false)}
          initial={false}
          animate={{ y: hidden ? "-100%" : "0%" }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className={cn(
            "fixed inset-x-0 top-0 z-50 px-margin pt-6 transition-colors max-md:pt-4",
            brand,
            // 모바일 홈(2624:5445): 맨 위에서는 배경·작은 로고 없이 Menu 만 — 키비주얼 위에 뜬다
            overlay && atPageTop && "max-md:bg-transparent max-md:[&_a[aria-label=홈으로]]:invisible",
          )}
          style={{ height: isMobile ? HEADER_H.mobile.simple : height }}
        >
          {topRow}
        </motion.header>
        {menu}
      </>
    );
  }

  const rowH = isMobile ? HEADER_H.mobile[showFilterRow ? "filters" : "archive"] : HEADER_H.desktop;

  return (
    <>
      <motion.header
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
        initial={false}
        animate={{ height: expanded ? rowH.expanded : rowH.collapsed }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "fixed inset-x-0 top-0 z-50 flex flex-col overflow-hidden px-margin py-6 max-md:pt-[15px]",
          showFilterRow ? "max-md:pb-1.5" : "max-md:pb-5",
          brand,
        )}
      >
        {/* Default 상태에서만 보이는 로고·내비 행.
          Scroll(74px) 에서는 높이까지 0 으로 접어야 둘째 줄이 화면에 남는다 */}
        <motion.div
          initial={false}
          animate={{ height: expanded ? "auto" : 0, opacity: expanded ? 1 : 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          aria-hidden={!expanded}
          className="shrink-0 overflow-hidden"
        >
          {firstRow}
        </motion.div>

        {secondRow}
      </motion.header>
      {menu}
    </>
  );
}

/**
 * 모바일 상세의 ← (akar arrow-left 18). 목록에서 들어왔으면 브라우저 뒤로가기로 돌아가
 * 고른 분야·스크롤 위치가 그대로 남게 하고, 주소로 바로 들어왔으면 목록 주소로 간다.
 */
function BackLink({ href }: { href: string }) {
  const router = useRouter();
  return (
    <Link
      href={href}
      aria-label="목록으로"
      className="block size-[18px] md:hidden"
      onClick={(e) => {
        if (document.referrer.startsWith(window.location.origin) && window.history.length > 1) {
          e.preventDefault();
          router.back();
        }
      }}
    >
      <ArrowUpRight className="size-[18px] -rotate-135" />
    </Link>
  );
}
